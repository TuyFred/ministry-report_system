# Images Directory

Please add your ministry images here:
1. slide1.jpg - Group photo
2. slide2.jpg - Ministry Formation blue background
3. slide3.jpg - Globe image
4. slide4.jpg - Bible study image

The images you provided should be saved as:
- slide1.jpg (the group photo)
- slide2.jpg (Ministry Formation with fish logo)
- slide3.jpg (globe image)
- slide4.jpg (children reading bible)
